
chrome.extension.onMessage.addListener(function(msg, sender, sendResponse) {
	if (msg.action == 'bypass') {
		var urlParams = new URLSearchParams(window.location.search);
		var content = document.getElementById("primary-inner");
		content.innerHTML = `<video width="100%" src="https://api.tubefixer.ovh/video/hd/${urlParams.get('v')}" controls autoplay>`;
	}
  });